<?php

	########## MySql details (Replace with yours) #############
	$db_username = "leonelse_chtuser"; //Database Username
	$db_password = "0s3zHeRLSZz7"; //Database Password
	$hostname = "localhost"; //Mysql Hostname
	$db_name = "leonelse_chat"; //Database Name

	// Create connection
	$conn = new mysqli($hostname, $db_username, $db_password, $db_name);

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 

?>