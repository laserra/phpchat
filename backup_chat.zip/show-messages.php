<?php
error_reporting(E_ERROR);
	include('connect.php'); 
	
	//Get the first 50 messages ordered by time
	$result = mysqli_query($conn, "SELECT * FROM messages ORDER BY timestamp desc limit 0,150");
	$messages = array();
	//$num_messages=mysqli_num_rows($result);
	
	//echo "<script type='text/javascript'>console.log(".mysqli_num_rows($result).")</script>";
	$usecolor="";
	//Loop and get in an array all the rows until there are not more to get
	while($row = mysqli_fetch_array($result)){

		//$color=mysqli_query($conn, "SELECT google_color FROM google_users WHERE google_name='".str_replace("_"," ",$row[id_user])."'");
		//$color=mysqli_query($conn,"SELECT IFNULL(google_color,0) FROM google_users WHERE google_name='".str_replace("_"," ",$row[id_user])."'");
		$color = current($conn->query("SELECT IFNULL(google_color,'') FROM google_users WHERE google_name='".str_replace("_"," ",$row[id_user])."'")->fetch_assoc());

		
		/*while($colorrow = mysqli_fetch_assoc($color)){
			$usecolor=$row['google_color'];
			echo "<script type='text/javascript'>console.log('".$colorrow['google_color']."');</script>";
		}*/

		//$color_string=(String)$color;

		if($color==''){
			$color='#555';
		    //$color = current($conn->query("SELECT google_color FROM google_users WHERE google_name='".str_replace("_"," ",$colorrow[0])."'")->fetch_assoc());
		}

	   //$color = (string)mysqli_query($conn,"SELECT google_color FROM google_users WHERE google_name='".str_replace("_"," ",$row[id_user])."'");
	   $messages[] = "<div class='message'><div class='messagecontent' style='font-weight: bold; color:".$color."'>" . $row[id_user].": ".$row[message] . "</div></div>";
	   
	   //Put the messages in divs and then in an array
	   //$messages[] = "<div class='message'><div class='messagecontent' style='font-weight: bold; color:".$color."'>" . $row[id_user].": ".$row[message] . "</div></div>";
	   //<div class='messagehead'>" . $row[id_user] . " - " . date('g:i A M, d Y',$row[time]) . "</div>
	   //The last posts date
	   $old = $row[timestamp];
	}

	//Display the messages in an ascending order, so the newest message will be at the bottom
	for($i=149;$i>=0;$i--){
	   echo $messages[$i];
	}
	
	//This is the more important line, this deletes each message older then the 10th message ordered by time, so the table will never have to store more than 10 messages.
	//mysqli_query($conn, "DELETE FROM messages WHERE timestamp < " . $old);
?>